export const login = (user) => ({type: "LOGIN", payload: user})

export const logout = () => ({type: "LOGOUT"})

export const setPosts = (posts) => ({
    type: "SET_POSTS", 
    payload: posts
})

export const updatePost = (post) => ({
    type: "UPDATE_POST",
    payload: post
});


export const addPost = (post) => ({
    type: "ADD_POST",
    payload: post
})

export const removePost = (postId) => ({
  type: "REMOVE_POST",
  payload: postId,
});

