import React from "react";
import './home.css';
import Sidenav from "../navigation/Sidenav";
import Timeline from "../timeline/Timeline";


export default function Home(){
  return(
    <div className="home-page">
      <div className="home-navbar">
      <Sidenav/>
      </div>
      <div className="home-line">
        <Timeline/>
      </div>
    </div>
  )
}