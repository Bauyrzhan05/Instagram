import './login.css';
import insta from '../../images/instaWord1.png'
import { Link, useNavigate } from 'react-router-dom';
import { assets } from '../../../assets/frontend_assets/assets';
import { useEffect, useState } from 'react';
import { useDispatch } from 'react-redux';
import { login } from '../../redux/export';
import { toast } from 'react-toastify';



export default function Login(){

    const dispatch = useDispatch();
    const navigate = useNavigate();

    const [isSignIn, setIsSignIn] = useState(false)
    const [name, setName] = useState('')
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");


    const handleLogin = async () => {
        console.time()

        try {
            const response  = await fetch("http://127.0.0.1:5000/api/auth/login", {
                method: "POST",
                headers: { 'Content-Type': 'application/json' },
                body:  JSON.stringify({ email, password })
            });

            const data = await response.json()

            if (data.success){
                dispatch(login(data));
                localStorage.setItem("token", JSON.stringify(data.token));
                navigate('/')
                console.timeEnd()
            }else{
                toast.error(data.msg || "Login failed");
            }

        } catch (err) {
            console.log(err);
        }
        console.timeEnd()
    }

    const handleRegister = async () => {
        console.time()
        try {
            const response = await fetch("http://127.0.0.1:5000/api/auth/register", {
                method: "POST",
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({name, email, password})
            })

           const data = await response.json();

            if (data.success){
                toast.success(data.msg);
                setIsSignIn(false)
                console.timeEnd()
            }else{
                toast.error(data.msg);
            }
        } catch (err) {
            console.log(err) 
        }
        console.timeEnd()
    }
    
    const handle = () => {
        setIsSignIn(!isSignIn)
        setName('')
    }



    return(
        <div className="login">
            <div className="log">
                <div className="insta">
                    <img src={insta} alt="" />
                </div>
                <div className="">
                    {isSignIn 
                    ? <input 
                    type="text" 
                    placeholder="Name" 
                    value={name} 
                    onChange={(e) => setName(e.target.value)} 
                    required />
                    :<></>
                    }
                    <input 
                    type="text" 
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="Email" 
                    required />
                    <input 
                    type="password" 
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="Password" 
                    required />
                </div>
                <div className="button">
                    <button onClick={isSignIn ? handleRegister : handleLogin}>
                        {isSignIn ? 'Sign up' : 'Log in'}
                    </button>
                </div>
                <p>---------------- OR ----------------</p>
                <p>People who use our service may have uploaded your contact information to Instagram. Learn More</p>
            </div>
            <div className='change'>
                {!isSignIn
                ? <p>Don't have an account? <Link className='link' onClick={handle}>Sign up</Link></p>
                : <p>Have an account? <Link className='link' onClick={handle}>Log in</Link></p>
                }
            </div>
            <div className='app'>
                <p>Get the app.</p>
                <div className="store-images">
                    <img src={assets.play_store} alt="Google Play" />
                    <img src={assets.app_store} alt="App Store" />
                </div>
            </div>
        </div>
    );
}