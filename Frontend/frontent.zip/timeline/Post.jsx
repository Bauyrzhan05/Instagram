import { useEffect, useState } from "react";
import './Post.css'
import MoreHorizIcon from '@mui/icons-material/MoreHoriz';
import FavoriteBorderIcon from '@mui/icons-material/FavoriteBorder';
import ChatBubbleOutlineIcon from '@mui/icons-material/ChatBubbleOutline';
import BookmarkBorderIcon from '@mui/icons-material/BookmarkBorder';
import TelegramIcon from '@mui/icons-material/Telegram';
import { toast } from "react-toastify";
import 'react-toastify/dist/ReactToastify.css'; 

export default function Post({id, userId, description, image, timePost, likes, onDelete}){

    const [author, setAuthor] = useState(null);

    const token = JSON.parse(localStorage.getItem('token'));

    const fetchAuthorProfile = async () => {
        try {
            const response = await fetch(`http://localhost:5000/api/posts/get-user/${userId}`, {
                headers: {
                    'Authorization': `Bearer ${token}`,
                    'Content-Type': 'application/json'
                }
            });
            const data = await response.json();

            if (data.success) {
                setAuthor(data.data);
            } else {
                toast.error(data.message);
            }
        } catch (err) {
            console.error("Author profile fetch error:", err);
        }
    };

    const handleDelete = () => {
        const confirmToast = toast.info(
            ({ closeToast }) => (
            <div style={{ textAlign: 'center' }}>
                <p style={{ marginBottom: "10px" }}>Are you sure you want to delete this post?</p>
                <div style={{ display: 'flex', justifyContent: 'center', gap: '10px' }}>
                <button
                    style={{
                    padding: '6px 12px',
                    backgroundColor: '#ff4d4f',
                    color: '#fff',
                    border: 'none',
                    borderRadius: '4px',
                    cursor: 'pointer'
                    }}
                    onClick={async () => {
                    closeToast(); // жабу confirm-ті

                    try {
                        const response = await fetch(`http://localhost:5000/api/posts/remove/${id}`, {
                        method: "DELETE",
                        headers: {
                            "Authorization": `Bearer ${token}`,
                            "Content-Type": "application/json"
                        }
                        });
                        const data = await response.json();

                        if (data.success) {
                            toast.success(data.message);
                            onDelete(); 
                        } else {
                            toast.error(data.message);
                        }
                    } catch (err) {
                        console.error(err);
                    }
                    }}
                >
                    Yes
                </button>
                <button
                    style={{
                    padding: '6px 12px',
                    backgroundColor: '#1890ff',
                    color: '#fff',
                    border: 'none',
                    borderRadius: '4px',
                    cursor: 'pointer'
                    }}
                    onClick={() => closeToast()}
                >
                    No
                </button>
                </div>
            </div>
            ),
            { autoClose: false, closeOnClick: false, draggable: false }
        );
    };

    useEffect(() => {
        if (userId) {     
        fetchAuthorProfile();
        }
    }, [userId]);


    return(
        <div className="post">
            <div className="post-header">
                <div className="post-header-author">
                    <img src={author?.avatar ? `http://localhost:5000/${author.avatar}` : "https://i.pinimg.com/736x/15/0f/a8/150fa8800b0a0d5633abc1d1c4db3d87.jpg"} alt="" />
                    <span style={{ marginLeft: "8px", color: "black" }}>
                        {author?.username || "Loading..."}
                    </span>
                    <span style={{ marginLeft: "12px", fontSize: "12px", color: "gray" }}>
                        {timePost}
                    </span>
                </div>
                <div className="dlt">
                    <MoreHorizIcon className="more-icon" />
                    <p className="delete-text" onClick={handleDelete}>delete post</p>
                </div>

            </div>
            <div className="post-img">
                <img src={`http://localhost:5000/${image}`} alt="" />
            </div>
            <div className="post-footer">
                <div className="post-footer-icons">
                    <div className="post-icons-main">
                        <FavoriteBorderIcon className="post-icon"/>
                        <ChatBubbleOutlineIcon className="post-icon"/>
                        <TelegramIcon className="post-icon"/>
                    </div>
                    <div className="post-icons-save">
                        <BookmarkBorderIcon className="post-icon"/>
                    </div>
                </div>
                {likes} likes
            </div>
            <div className="postBio">
                <p>{author?.username}</p>
                {description}
            </div>
        </div>
    )
}