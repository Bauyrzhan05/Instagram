import React, { useEffect, useState } from "react";
import './Suggestions.css';
import { Avatar } from "@mui/material";
import { toast } from "react-toastify";
import { Link } from "react-router-dom";

export default function Suggestions() {

    const [author, setAuthor] = useState('')
    const [suggestions, setSuggestions] = useState([])
    const token = JSON.parse(localStorage.getItem("token"));

    const fetchProfile = async () => {
        try {
            const response = await fetch("http://127.0.0.1:5000/api/profile/me", {
                headers: {'Authorization': `Bearer ${token}`}
            })

            const data = await response.json();
            if (data.success){
                setAuthor(data.data);
            }else toast.error(data.message);
        } catch (err) {
            console.log(err);
        }
    }

    const fetchSuggestions = async () => {
        try {
            const response = await fetch("http://127.0.0.1:5000/api/follows/recommendations", {
                headers: {Authorization: `Bearer ${token}`}
            });

            const data = await response.json();
            if (data.success){
                setSuggestions(data.recommendations);
            }
        } catch (err) {
            console.log(err)
        }
    }

    useEffect(() => {
        fetchProfile();
        fetchSuggestions();
    },[])
    
    return (
        <div className="suggestions">
            <div className="suggestions-usernames">
                <div className="suggestions-username">
                    <div className="user-left">
                        <span className="avatar">
                            <img src={author?.avatar ? `http://localhost:5000/${author.avatar}` : "https://i.pinimg.com/736x/15/0f/a8/150fa8800b0a0d5633abc1d1c4db3d87.jpg"} alt="" />
                        </span>
                        <div className="user-info">
                            <span className="username">{author.username}</span>
                        </div>
                    </div>
                    <button className="follow-btn">Switch</button>
                </div>
            </div>
            <div className="suggestions-title">
                Suggested for you
            </div>
            {
                suggestions.length === 0
                ? <></>
                :suggestions.map((sugges) => {
                    return(
                        <div className="suggestions-usernames" key={sugges._id}>
                            <div className="suggestions-username">
                                <div className="user-left">
                                    <span className="avatar">
                                        <img src={sugges?.avatar ? `http://localhost:5000/${sugges.avatar}` : "https://i.pinimg.com/736x/15/0f/a8/150fa8800b0a0d5633abc1d1c4db3d87.jpg"} alt="" />
                                    </span>
                                    <div className="user-info">
                                        <Link to={`/user-profile/${sugges._id}`} className="username">{sugges.username}</Link>
                                        <span className="relation">Suggested for you</span>
                                    </div>
                                </div>
                                <button className="follow-btn">follow</button>
                            </div>
                        </div>
                    )
                })
            }
            
        </div>
        
        
    )
}