import { useEffect, useState } from "react"
import '../Post.css';

export default function Comment({userId, parentId, text, onReply, children = []}) {

    const [commentAuthor, setCommentAuthor] = useState([]);
    const [showReplies, setShowReplies] = useState(false);

    useEffect(() => {
        fetch(`http://127.0.0.1:5000/api/posts/get-user/${userId}`)
        .then(res => res.json())
        .then(data => setCommentAuthor(data.data))
    }, [])

    return(
        <>
        <div className="post-header2">
            <img src={commentAuthor?.avatar ? `http://localhost:5000/${commentAuthor.avatar}` : "https://i.pinimg.com/736x/15/0f/a8/150fa8800b0a0d5633abc1d1c4db3d87.jpg"} alt="" />
            <span className="username blue-text">{commentAuthor.username}</span>
            <p>{text}</p>
        </div>
        <div style={{ marginLeft: '40px' }}>
            <span className="reply" onClick={() => onReply(parentId, commentAuthor.username)}>Reply</span>

            {children.length > 0 && (
                <div className="view-replies" onClick={() => setShowReplies(!showReplies)}>
                    {showReplies ? `Hide replies (${children.length})` : `View replies (${children.length})`}
                </div>
            )}
        </div>

        {showReplies && (
            <div className="nested-replies">
                {
                    children.map((child, index) => (
                        <Comment
                            key={index}
                            userId={child.user_id}
                            text={child.text}
                            parentId={child._id}
                            onReply={onReply}
                            children={child.children || []}
                        />
                    ))
                }
            </div>
        )}
        </>
    )
}