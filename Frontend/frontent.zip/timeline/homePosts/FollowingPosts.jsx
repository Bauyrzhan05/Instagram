import { useEffect, useState } from "react"
import { toast } from "react-toastify";
import { useSelector } from "react-redux";
import PostCart from "./PostCart";
import Story from "./Story";

export default function FollowingPosts(){

    const [author, setAuthor] = useState(null);

    const posts = useSelector((state) => state.post.posts);
    const token = JSON.parse(localStorage.getItem('token'));

    const fetchMe = async () => {
        try {
            const response = await fetch("http://localhost:5000/api/profile/me", {
                headers: {
                   'Authorization': `Bearer ${token}` 
                }
            });
            
            const data = await response.json();
            if (data.success){
                setAuthor(data.data)
            }else{
                toast.error(data.message)
            }
        } catch (err) {
            console.log(err)
        }
    }

    useEffect(() => {
        fetchMe(); 
    }, [])

    const myFollowingPost = posts.filter((post) => author?.following?.includes(post.user_id))

    return(
        <>
        <Story/>
        <div>
            {
                myFollowingPost.length === 0
                ? <>No posts</>
                :myFollowingPost.map((post) => {
                    return <PostCart
                    key={post._id}
                    postId={post._id}
                    userId={post.user_id}
                    description={post.description} 
                    image={post.media_url} 
                    timePost={new Date(post.created_at.$date).toLocaleString()} 
                    likes={post.likes || []} 
                    />
                })
            }
        </div>
        </>
        
    )
}