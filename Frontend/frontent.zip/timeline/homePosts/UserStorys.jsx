import { useEffect, useState } from 'react';
import './Story.css';

export default function UserStorys({stories, userId}){

    const [user, setUser] = useState([]);
    const [showStoryViewer, setShowStoryViewer] = useState(false);
    const [currentIndex, setCurrentIndex] = useState(0);
    const [viewedStories, setViewedStories] = useState([]);

    const token = JSON.parse(localStorage.getItem('token'))

    const fetchUser = async () => {
        try {
        fetch(`http://127.0.0.1:5000/api/posts/get-user/${userId}`)
        .then(res => res.json())
        .then(data => setUser(data.data))
        } catch (err) {
            console.log(err)
        }
    }

    const fetchStory = async (storyId) => {
        try {
            const res = await fetch(`http://127.0.0.1:5000/api/stories/story/${storyId}`,{
                headers: {Authorization: `Bearer ${token}`}
            });
            const data = await res.json();
            if(data.success){
                return data.story;
            }
        } catch (err) {
            console.log(err)
        }
    }

    const handleViewStory = async (index) => {
        const story = stories[index];
        const data = await fetchStory(story._id);
        if (data) {
            setViewedStories((prev) => {
                const updated = [...prev];
                updated[index] = data;
                return updated;
            });
        }
    };

    useEffect(() => {
        fetchUser()
    }, [])

    useEffect(() => {
        if (showStoryViewer) {
            handleViewStory(currentIndex);
        }
    }, [showStoryViewer, currentIndex]);

    const nextStory = () => {
        if (currentIndex < stories.length - 1) {
            setCurrentIndex((prev) => prev + 1);
        } else {
            setShowStoryViewer(false);
            setCurrentIndex(0);
        }
    };

    if (!user) return null;

    return(
        <div className='user-storys'>
            <img src={user.avatar ? `http://localhost:5000/${user.avatar}` : "https://i.pinimg.com/736x/15/0f/a8/150fa8800b0a0d5633abc1d1c4db3d87.jpg"} 
            alt=""
            style={{width:"60px", height:"60px", borderRadius:"50%", cursor:"pointer"}} 
            onClick={() => {
               setShowStoryViewer(true);
                setCurrentIndex(0);
                setViewedStories([]);
            }}
            />

            {showStoryViewer && viewedStories[currentIndex] && (
                <div className="story-overlay" onClick={nextStory}>
                    <div className="story-container">
                        <img
                            src={`http://localhost:5000/${viewedStories[currentIndex].media_url}`}
                            alt="story"
                            className="story-image"
                        />
                        <div className="story-top">
                            <img
                                src={user.avatar ? `http://localhost:5000/${user.avatar}` : "https://i.pinimg.com/736x/15/0f/a8/150fa8800b0a0d5633abc1d1c4db3d87.jpg"}
                                alt="avatar"
                                className="story-avatar"
                            />
                            <span className="story-username">{user.username}</span>
                        </div>
                        <div className="story-progress">
                            <div
                                className="story-progress-bar"
                                style={{ width: `${((currentIndex + 1) / stories.length) * 100}%` }}
                            />
                        </div>
                    </div>
                </div>
            )}

        </div>
    )
}