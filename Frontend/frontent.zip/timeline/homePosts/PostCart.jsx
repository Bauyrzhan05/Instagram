import "../Post.css"
import MoreHorizIcon from '@mui/icons-material/MoreHoriz';
import FavoriteIcon from '@mui/icons-material/Favorite';
import FavoriteBorderIcon from '@mui/icons-material/FavoriteBorder';
import ChatBubbleOutlineIcon from '@mui/icons-material/ChatBubbleOutline';
import BookmarkBorderIcon from '@mui/icons-material/BookmarkBorder';
import TelegramIcon from '@mui/icons-material/Telegram';
import { useEffect, useState } from "react";
import { data, Link } from "react-router-dom";
import { toast } from "react-toastify";
import { useDispatch } from "react-redux";
import { updatePost } from "../../redux/export";
import Comment from "./Comment";

export default function PostCart({userId, postId, description, image, timePost, likes }){

    const [postAuthor, setPostAuthor] = useState({})
    const [like, setLike] = useState(false);
    const [showAddComment , setShowAddComment] = useState(false);
    const [text, setText] = useState('');
    const [postComments, setPostComments] = useState([]);
    const [replyTo, setReplyTo] = useState(null);


    const token = JSON.parse(localStorage.getItem("token"));
    const dispatch = useDispatch();

    useEffect(() => {
        fetch(`http://127.0.0.1:5000/api/posts/get-user/${userId}`)
        .then(res => res.json())
        .then(data => setPostAuthor(data.data))
    }, [])

    const handleLike = async () =>{
        try {
            const response = await fetch(`http://localhost:5000/api/post-likes/like/${postId}`,{
                method: "POST",
                headers: {'Authorization': `Bearer ${token}`}
            })

            const data = await response.json();
            if (data.success){
                dispatch(updatePost(data.data)) 
                setLike(!like)
            }else toast.error(data.message)
        } catch (err) {
            console.log(err)
        }
    }

    const checkLikedStatus = async () => {
        try {
            const res = await fetch("http://127.0.0.1:5000/api/profile/me", {
                headers: { Authorization: `Bearer ${token}` }
            });
            const data = await res.json();
            if (data.success) {
                const currentUserId = data.data._id;
                const stringLikes = likes.map(id => String(id.$oid));
                if (stringLikes.includes(currentUserId)) {
                    setLike(true);
                } else {
                    setLike(false);
                }
            }
        } catch (err) {
            console.log("Error checking liked status:", err);
        }
    };

    const handleComment = async () => {
        try {
            const response = await fetch(`http://127.0.0.1:5000/api/comments/comment/${postId}`, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    Authorization: `Bearer ${token}`
            },
                body: JSON.stringify({text, parent_id: replyTo})
            });
            const data = await response.json();
            
            if (data.success){
                setText("")
                setReplyTo(null)
                fetchPostComments()
            }
        } catch (err) {
            console.log(err)
        }
    }

    function buildCommentTree(comments) {
        const map = {};
        const roots = [];

        comments.forEach(comment => {
            comment.children = [];
            map[comment._id] = comment;
        });

        comments.forEach(comment => {
            if (comment.parent_id) {
                map[comment.parent_id]?.children.push(comment);
            } else {
                roots.push(comment);
            }
        });
        return roots;
    }

    const fetchPostComments = async () => {
        try {
            const res = await fetch(`http://127.0.0.1:5000/api/comments/${postId}`);
            const data = await res.json();
            if (data.success) {
                const nested = buildCommentTree(data.data);
                setPostComments(nested);
            }
        } catch (err) {
            console.log(err);
        }
    };

    useEffect(() => {
        checkLikedStatus()
        fetchPostComments()  
    }, [])

    return(
        <div className="post">
            <div className="post-header">
                <div className="post-header-author">
                    <img src={postAuthor?.avatar ? `http://localhost:5000/${postAuthor.avatar}` : "https://i.pinimg.com/736x/15/0f/a8/150fa8800b0a0d5633abc1d1c4db3d87.jpg"} alt="" />
                    <Link to={`/user-profile/${postAuthor._id}`} style={{ marginLeft: "8px", color: "black", cursor: "pointer", fontWeight: "550" }}>
                        {postAuthor?.username || "Loading..."}
                    </Link>
                    <span style={{ marginLeft: "12px", fontSize: "12px", color: "gray" }}>
                        {timePost}
                    </span>
                </div>
                <div className="dlt">
                    <MoreHorizIcon/>
                </div>
            </div>
            <div className="post-img">
                <img src={`http://localhost:5000/${image}`} alt="" />
            </div>
            <div className="post-footer">
                <div className="post-footer-icons">
                    <div className="post-icons-main">
                        {
                            like ? (
                                <FavoriteIcon
                                    className="post-icon like-icon liked"
                                    onClick={handleLike}
                                />
                            ) : (
                                <FavoriteBorderIcon
                                    className="post-icon like-icon"
                                    onClick={handleLike}
                                />
                            )
                        }
                        <ChatBubbleOutlineIcon onClick={() => setShowAddComment(postId)} className="post-icon" />
                        <TelegramIcon className="post-icon"/>
                    </div>
                    <div className="post-icons-save">
                        <BookmarkBorderIcon className="post-icon"/>
                    </div>
                </div>
                {likes?.length} likes
            </div>
            <div className="postBio">
                <p>{postAuthor.username}</p>
                {description}
            </div>

            {showAddComment === postId && (
                <div className="modal-overlay">
                    <div className="instagram-post-modal">
                    {/* Left side: Image */}
                    <div className="post-image">
                        <img src={`http://localhost:5000/${image}`} alt="" />
                    </div>

                    {/* Right side: Comments + Info */}
                    <div className="post-info">
                        <div className="post-header">
                            <img src={postAuthor?.avatar ? `http://localhost:5000/${postAuthor.avatar}` : "https://i.pinimg.com/736x/15/0f/a8/150fa8800b0a0d5633abc1d1c4db3d87.jpg"} alt="" />
                            <span className="username">{postAuthor.username}</span>
                            <button className="close-btn" onClick={() => setShowAddComment(false)}>✕</button>
                        </div>
                        <hr></hr>
                        <div className="post-header2">
                            <img src={postAuthor?.avatar ? `http://localhost:5000/${postAuthor.avatar}` : "https://i.pinimg.com/736x/15/0f/a8/150fa8800b0a0d5633abc1d1c4db3d87.jpg"} alt="" />
                            <span className="username">{postAuthor.username}</span>
                            <p>{description}</p>
                        </div>

                        {/* Comments */}
                        <div className="comment-list">
                            {
                                postComments.length === 0
                                ? <></>
                                : postComments.map((comment, ind) => {
                                    return(
                                        <Comment 
                                        key={ind} 
                                        userId={comment.user_id} 
                                        postId={comment.post_id}
                                        text={comment.text}
                                        parentId={comment._id}
                                        onReply={(replyId, replyUsername) => {
                                            setReplyTo(replyId);
                                            setText(`@${replyUsername}`)
                                        }}
                                        children={comment.children || []}
                                        />
                                    ) 
                                })
                            }
                        </div>

                        {/* Likes and time */}
                        <div className="post-stats">
                            <span className="likes-count">{likes?.length} likes</span>
                            <span className="post-time">{timePost}</span>
                        </div>

                        {/* Comment input */}
                        <div className="comment-input-box">
                            {replyTo && (
                                <div className="replying-to">
                                    <button onClick={() => {
                                        setReplyTo(null);
                                        setText("");
                                    }}>Cancel</button>
                                </div>
                            )}
                        <input
                            type="text"
                            placeholder="Add a comment..."
                            value={text}
                            onChange={(e) => setText(e.target.value)}
                        />
                        <button onClick={handleComment}>Post</button>
                        </div>
                    </div>
                    </div>
                </div>
            )}
        </div>
    )
}