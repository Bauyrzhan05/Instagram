import { useEffect, useState } from 'react';
import './Story.css';
import { toast } from 'react-toastify';
import UserStorys from './UserStorys';
import DeleteIcon from '@mui/icons-material/Delete';
import RemoveRedEyeIcon from '@mui/icons-material/RemoveRedEye';

export default function Story(){

    const [showAddStory, setShowAddStory] = useState(false);
    const [media, setMedia] = useState(null);
    const [previewUrl, setPreviewUrl] = useState(null);
    const [storys, setStorys] = useState([]);
    const [showMyStorys, setShowMyStorys] = useState(false);
    const [author, setAuthor] = useState([]);
    const [currentIndex, setCurrentIndex] = useState(0);
    const [showViews, setShowViews] = useState(false);
    const [views, setViews] = useState([]);

    const token = JSON.parse(localStorage.getItem("token"));

    const handleStoryUpload = async () => {
        if (!media) {
        toast.error("Please select a file");
        return;
        }

        const formData = new FormData();
        formData.append("media", media);

        try {
        const response = await fetch("http://127.0.0.1:5000/api/stories/create", {
            method: "POST",
            headers: { Authorization: `Bearer ${token}`,},
            body: formData,
        });

        const data = await response.json();

        if (data.success) {
            toast.success(data.message);
            setMedia(null);
            setPreviewUrl(null);
            setShowAddStory(false);
            fetchStorys();
        } else {
            toast.error("Failed to upload story.");
        }
        } catch (err) {
        console.log(err);
        toast.error("Something went wrong.");
        }
    };

    const fetchMe = async () => {
        try {
            const response = await fetch("http://localhost:5000/api/profile/me", {
                headers: {
                   'Authorization': `Bearer ${token}` 
                }
            });
            
            const data = await response.json();
            if (data.success){
                setAuthor(data.data)
            }else{
                toast.error(data.message)
            }
        } catch (err) {
            console.log(err)
        }
    }

    const fetchStorys = async () => {
        try {
            const res = await fetch("http://127.0.0.1:5000/api/stories/story", {
                headers: {Authorization: `Bearer ${token}`}
            })
            const data = await res.json();
            if (data.success){
                setStorys(data.stories);
            }
        } catch (err) {
            console.log(err)
        }
    }

    const myStorys = storys.filter((s) => s.user_id === author._id)
    
    const uniqueUserStoriesMap = new Map();

    storys.forEach((story) => {
        if (author?.following?.includes(story.user_id) && !uniqueUserStoriesMap.has(story.user_id)) {
            uniqueUserStoriesMap.set(story.user_id, []);
        }
        if (author?.following?.includes(story.user_id)) {
            uniqueUserStoriesMap.get(story.user_id).push(story);
        }
    });

    const uniqueUserStories = Array.from(uniqueUserStoriesMap.entries()); // [[user_id, [story1, story2]], ...]

     const handleDeleteStory = async (storyId) => {
        try {
            const response = await fetch(`http://127.0.0.1:5000/api/stories/delete/${storyId}`,{
                method: 'DELETE',
                headers: {Authorization: `Bearer ${token}`}
            });
            const data = await response.json();
            if (data.success){
                toast.success(data.message)
                fetchStorys()
                setShowMyStorys(false)
            }else toast.error(data.error)
        } catch (err) {
            console.log(err);
        }
    }

    const fetchViewsStory = async (storyId) => {
        try {
            const res = await fetch(`http://127.0.0.1:5000/api/stories/story/${storyId}/views`, {
                headers: {Authorization: `Bearer ${token}`}
            });
            const data = await res.json();
            if (data.success){
                setViews(data.viewers)
            }else toast.error(data.error)
        } catch (err) {
            console.log(err)
        }
    }

    console.log(views);

    useEffect(() => {
        fetchStorys();
        fetchMe();
    },[])

    return(
        <div className='story'>
            <div className='my-story'>
                {
                    myStorys.length === 0
                    ? <></>
                    :<div>
                        <img src={author?.avatar ? `http://localhost:5000/${author.avatar}` : "https://i.pinimg.com/736x/15/0f/a8/150fa8800b0a0d5633abc1d1c4db3d87.jpg"} 
                        alt=""
                        style={{width:"60px", height:"60px", borderRadius:"50%", cursor:"pointer"}} 
                        onClick={() => {
                            setShowMyStorys(true)
                            setCurrentIndex(0)
                        }}
                        />
                    </div>
                }
            <p onClick={() => setShowAddStory(true)} style={{ cursor: 'pointer', color: 'blue' }}>Your story</p>
            </div>
            <div>
                {
                    uniqueUserStories.length === 0
                    ? <></>
                    :uniqueUserStories.map(([userId, stories], index) => {
                        return(
                            <UserStorys 
                            key={index}
                            userId={userId}
                            stories={stories}
                            /> 
                        )
                    })
                }
            </div>

            {showAddStory && (
                <>
                <div 
                    className="overlay" 
                    style={{
                    position: 'fixed',
                    top: 0, left: 0,
                    width: '100vw',
                    height: '100vh',
                    backgroundColor: 'rgba(0, 0, 0, 0.5)',
                    zIndex: 999
                    }}
                    onClick={() => setShowAddStory(false)}
                />

                <div 
                    className="story-modal"
                    style={{
                    flexDirection: "column",
                    position: 'fixed',
                    top: '50%',
                    left: '50%',
                    transform: 'translate(-50%, -50%)',
                    backgroundColor: 'white',
                    padding: '20px',
                    borderRadius: '12px',
                    zIndex: 1000,
                    width: '90%',
                    maxWidth: '400px',
                    boxShadow: '0 4px 12px rgba(0,0,0,0.2)'
                    }}
                >
                    <h3 style={{ textAlign: 'center' }}>Add to Story</h3>
                    <input
                    type="file"
                    accept="image/*,video/*"
                    onChange={(e) => {
                        const file = e.target.files[0];
                        setMedia(file);
                        if (file) {
                        setPreviewUrl(URL.createObjectURL(file));
                        }
                    }}
                    style={{ marginBottom: '10px' }}
                    />

                    {previewUrl && (
                    <div style={{ marginBottom: '10px' }}>
                        <img 
                        src={previewUrl} 
                        alt="preview" 
                        style={{ width: '100%', maxHeight: '300px', objectFit: 'cover' }} 
                        />
                    </div>
                    )}

                    <button 
                    onClick={handleStoryUpload} 
                    style={{
                        width: '100%',
                        padding: '10px',
                        backgroundColor: '#3897f0',
                        color: 'white',
                        border: 'none',
                        borderRadius: '6px',
                        cursor: 'pointer'
                    }}
                    >
                    Share Story
                    </button>
                </div>
                </>
            )}

            {showMyStorys && (
            <div className="my-story-viewer">
                <div className='icons'>
                    <button onClick={() => setShowMyStorys(false)} className="close-btn">×</button>
                    {
                        myStorys.map((s) => {
                        return(
                            <DeleteIcon className='delete-story' onClick={() => handleDeleteStory(s._id)}/>
                        )
                        })
                    }
                    {
                        myStorys.map((s) => {
                            return(
                            <div className='views'>
                                <RemoveRedEyeIcon  
                                onClick={() => {
                                    fetchViewsStory(s._id);
                                    setShowViews(true);
                                }}/>
                                {(s.views?.length || 0)} views
                            </div>   
                            )
                        })
                    }
                    {showViews && (
                    <div className="show-viewers">
                        <div className="viewers-modal">
                            <>
                                <h3>Seen by</h3>
                                <button className="close-btn" onClick={() => setShowViews(false)}>×</button>
                            </>
                            <div className="viewers-list">
                                {views.length === 0 ? (
                                <p style={{ textAlign: 'center', color: 'gray' }}>No views yet</p>
                                ) : (
                                views.map((user) => (
                                    <div key={user._id} className="viewer-item">
                                        <img
                                            src={user.avatar ? `http://localhost:5000/${user.avatar}` : "https://i.pinimg.com/736x/15/0f/a8/150fa8800b0a0d5633abc1d1c4db3d87.jpg"}
                                            alt="avatar"
                                        />
                                        <span>{user.username}</span>
                                    </div>
                                ))
                                )}
                            </div>
                        </div>
                    </div>
                    )}

                </div>
                <button
                    className="nav-btn left"
                    onClick={() => setCurrentIndex((prev) => (prev > 0 ? prev - 1 : prev))}
                >
                    ←
                </button>

                <div className="story-content">
                    <img
                    src={myStorys[currentIndex] && myStorys[currentIndex].media_url ? `http://localhost:5000/${myStorys[currentIndex].media_url}` : <></>}
                    alt="story"
                    />
                </div>

                <button
                    className="nav-btn right"
                    onClick={() => setCurrentIndex((prev) =>
                    prev < myStorys.length - 1 ? prev + 1 : prev
                    )}
                >
                    →
                </button>
            </div>
            )}
        </div>
    )
}