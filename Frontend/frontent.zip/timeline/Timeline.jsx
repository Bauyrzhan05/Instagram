import React from "react";
import './Timeline.css';
import Suggestions from "./Suggtesions";
import Post from "./Post";
import { Outlet, useLocation } from "react-router-dom";


export default function Timeline(){

    const location = useLocation();
    const showSuggestions  = location.pathname === '/'
    return(
        <div className="timeline">
            <div className="timeline-left">
                <Outlet/>
            </div>
            <div className="timeline-right">
                {
                    showSuggestions ? <Suggestions/> : <></>
                }
            </div>
        </div>
    );
}