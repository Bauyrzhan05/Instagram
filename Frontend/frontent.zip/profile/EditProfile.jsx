import { useEffect, useState } from 'react';
import './EditProfile.css';
import { toast } from 'react-toastify';
import { useNavigate } from 'react-router-dom';

const EditProfile = () => {
  const [bio, setBio] = useState('');
  const [avatar, setAvatar] = useState(null)
  const [avatarPreview, setAvatarPreview] = useState(null)
  const [username, setUsername] = useState('');
  const bioCharCount = bio.length;
  const maxBioLength = 150;

  const navigate = useNavigate();

  useEffect(() => {

    const token = JSON.parse(localStorage.getItem('token'));
    if (!token) return;

    const fetchProfile = async () => {
        try {
            const response = await fetch('http://127.0.0.1:5000/api/profile/me', {
                method: "GET",
                headers: {
                    "Authorization": `Bearer ${token}`
                },
            });

            const data = await response.json();

            if (data.success){
                const user = data.data;
                setBio(user.bio || '');
                setAvatarPreview(`http://127.0.0.1:5000${user.avatar}`);
                setUsername(user.username);
            } else {
                toast.error("Профиль алу кезінде қате.");
            } 
        } catch (err) {
            console.log(err)
        }
    };
    fetchProfile();
    
  },[])
  


  const handleEdit = async () => {

    const token = JSON.parse(localStorage.getItem("token"))

    const formData = new FormData();
    formData.append('bio', bio)
    if (avatar){
        formData.append('avatar', avatar);
    }
    
    try {

        const response = await fetch('http://127.0.0.1:5000/api/profile/update', {
            method: "PUT",
            headers: {
                'Authorization': `Bearer ${token}`
            },
            body: formData,
        });

        const data = await response.json();

        if (data.success){
            toast.success('Profile updated');
            navigate('/profile');
        }else
            toast.error(data.messege);
        
    } catch (err) {
        console.log(err);
    }


  }

  return (
    <div className="profile-edit-container">
      <h1 className="edit-profile-title">Edit profile</h1>
      
      <div className="profile-header">
        <div className="profile-picture-container">
          <img 
            src={avatar ? URL.createObjectURL(avatar) : avatarPreview || "https://i.pinimg.com/736x/15/0f/a8/150fa8800b0a0d5633abc1d1c4db3d87.jpg"} 
            alt="Profile" 
            className="profile-picture"
            onError={(e) => {
                e.target.onerror = null; // prevent infinite loop
                e.target.src = "https://i.pinimg.com/736x/15/0f/a8/150fa8800b0a0d5633abc1d1c4db3d87.jpg";
            }}
          />
        </div>
        <div className="username-display">
          <p className="username">{username}</p>
        </div>
        <input
          type="file"
          accept="image/*"
          onChange={(e) => {
            setAvatar(e.target.files[0]);
            setAvatarPreview(URL.createObjectURL(e.target.files[0]));
          }}
          
          style={{ marginTop: '10px' }}
        />
      </div>
      
      <div className="form-section">
        <label className="section-label">Bio</label>
        <textarea
          className="bio-input"
          value={bio}
          onChange={(e) => setBio(e.target.value)}
          maxLength={maxBioLength}
        />
        <div className="char-counter">
          {bioCharCount} / {maxBioLength}
        </div>
      </div>

      <button className="submit" onClick={handleEdit}>Submit</button>
    </div>
  );
};

export default EditProfile;
