import { useEffect, useState } from "react";
import "./UserPosts.css"
import MoreHorizIcon from '@mui/icons-material/MoreHoriz';
import FavoriteIcon from '@mui/icons-material/Favorite';
import FavoriteBorderIcon from '@mui/icons-material/FavoriteBorder';
import ChatBubbleOutlineIcon from '@mui/icons-material/ChatBubbleOutline';
import BookmarkBorderIcon from '@mui/icons-material/BookmarkBorder';
import TelegramIcon from '@mui/icons-material/Telegram';
import { toast } from "react-toastify";
import { useDispatch } from "react-redux";
import { updatePost } from "../../redux/export";

export default function UserPosts({postId, id, description, image, timePost, likes}){

    const [author, setAuthor] = useState(null);
    const [like, setLike] = useState(false);

    const dispatch = useDispatch();
    const token = JSON.parse(localStorage.getItem('token'));

    const fetchAuthor = async () => {
        try {
            fetch(`http://127.0.0.1:5000/api/posts/get-user/${id}`)
            .then(res => res.json())
            .then(data => setAuthor(data.data))
        } catch (err) {
            console.log(err)
        }
    }

    const handleLike = async () =>{
            try {
                const response = await fetch(`http://localhost:5000/api/post-likes/like/${postId}`,{
                    method: "POST",
                    headers: {'Authorization': `Bearer ${token}`}
                })
    
                const data = await response.json();
                if (data.success){
                    dispatch(updatePost(data.data)) 
                    setLike(!like)
                }else toast.error(data.message)
            } catch (err) {
                console.log(err)
            }
        }

        const checkLikedAuthor = async () => {
            try {
                const response = await fetch("http://127.0.0.1:5000/api/profile/me", {
                    headers: {'Authorization': `Bearer ${token}`}
                });
                const data = await response.json();
                if(data.success){
                    const currentUserId = data.data._id;
                    const likedUser = likes.map((id) => String(id.$oid));
                    if(likedUser.includes(currentUserId)){
                        setLike(true)
                    }else setLike(false)
                }
            } catch (err) {
                console.log(err);
            }
        }
    

    useEffect(() =>{
        fetchAuthor()
        checkLikedAuthor()
    }, [])


    return(
        <div className="post">
            <div className="post-header">
                <div className="post-header-author">
                    <img src={author?.avatar ? `http://localhost:5000/${author.avatar}` : "https://i.pinimg.com/736x/15/0f/a8/150fa8800b0a0d5633abc1d1c4db3d87.jpg"} alt="" />
                    <span style={{ marginLeft: "8px", color: "black" }}>
                        {author?.username || "Loading..."}
                    </span>
                    <span style={{ marginLeft: "12px", fontSize: "12px", color: "gray" }}>
                        {timePost}
                    </span>
                </div>
                <div className="dlt">
                    <MoreHorizIcon/>
                </div>
            </div>
            <div className="post-img">
                <img src={`http://localhost:5000/${image}`} alt="" />
            </div>
            <div className="post-footer">
                <div className="post-footer-icons">
                    <div className="post-icons-main">
                        {
                            like ? (
                                <FavoriteIcon
                                    className="post-icon like-icon liked"
                                    onClick={handleLike}
                                />
                            ) : (
                                <FavoriteBorderIcon
                                    className="post-icon like-icon"
                                    onClick={handleLike}
                                />
                            )
                        }
                        <ChatBubbleOutlineIcon className="post-icon"/>
                        <TelegramIcon className="post-icon"/>
                    </div>
                    <div className="post-icons-save">
                        <BookmarkBorderIcon className="post-icon"/>
                    </div>
                </div>
                {likes?.length} likes
            </div>
            <div className="postBio">
                <p>{author?.username}</p>
                {description}
            </div>
        </div>
    )
}