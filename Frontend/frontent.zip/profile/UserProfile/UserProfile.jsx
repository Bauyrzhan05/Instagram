
import './UserProfile.css'
import MoreHorizIcon from '@mui/icons-material/MoreHoriz';
import PersonAddRoundedIcon from '@mui/icons-material/PersonAddRounded';
import { useEffect, useState } from 'react';
import { useSelector } from 'react-redux';
import { useParams } from 'react-router-dom';
import UserPosts from './UserPosts';
import { toast } from 'react-toastify';

export default function UserProfile(){

    const [follow, setFollow] = useState(true)
    const [user, setUser] = useState({})
    const [loading, setLoading] = useState(true);
    const posts = useSelector((state) => state.post.posts);
    const { id } = useParams();
    const token = JSON.parse(localStorage.getItem('token'));

    const fetchUserProfile = async () => {
        try {
            fetch(`http://127.0.0.1:5000/api/posts/get-user/${id}`)
            .then(response => response.json())
            .then(data => setUser(data.data))
        } catch (err) {
            console.log(err)
        }
    }

    const handleFollow = async () => {
        const url = follow
        ? `http://127.0.0.1:5000/api/follows/follow/${id}`
        : `http://127.0.0.1:5000/api/follows/unfollow/${id}`;
        try {
            const response = await fetch(url, {
                method: "POST",
                headers: { Authorization: `Bearer ${token}`},
            });
            const data = await response.json();
            if (data.success){
                setFollow(!follow)
            }else{
                toast.error(data.message || "error follow")
            }
        } catch (err) {
            console.log(err)
        }
    }

    const checkFollowing = async () => {
        try {
            const res = await fetch("http://127.0.0.1:5000/api/profile/me", {
                headers: { Authorization: `Bearer ${token}`}
            });
            const data = await res.json();
            if (data.success){
                const currentUser = data.data;
                if (currentUser.following.includes(id)){
                    setFollow(false)
                }else setFollow(true)
            }
        } catch (err) {
            console.log(err)
        }
    }

    useEffect(() => {
        fetchUserProfile()
        checkFollowing()
    }, [])

    const userPosts = posts.filter((post) => post.user_id === user._id)

    return (
        <div className="profile-container">
            <div className='profile'>   
                <img
                src={
                    user.avatar
                    ? `http://localhost:5000/${user.avatar}`
                    : "https://i.pinimg.com/736x/15/0f/a8/150fa8800b0a0d5633abc1d1c4db3d87.jpg"
                }
                alt="profile"
                width="150"
                />
                <div>
                <div className="profile-header">
                    <div className="profile-username">{user.username}</div>
                    <div className="profile-actions">
                        <button
                            className={follow ? "follow-btn" : "following-btn"}
                            onClick={handleFollow}
                        >
                            {follow ? "Follow" : "Following"}
                        </button>
                    </div>

                    <div style={{margin: '10px'}}>
                        <PersonAddRoundedIcon/>
                    </div>
                    <div style={{marginLeft: "6px"}}>
                       <MoreHorizIcon/>
                    </div>
                </div>

                <div className="profile-stats">
                    <div className="stat">
                        <span className="stat-number">{userPosts.length}</span>
                        <span className="stat-label">posts</span>
                    </div>
                    <div className="stat">
                        <span className="stat-number">{user.followers?.length || 0}</span>
                        <span className="stat-label">followers</span>
                    </div>
                    <div className="stat">
                        <span className="stat-number">{user.following?.length || 0 }</span>
                        <span className="stat-label">following</span>
                    </div>
                </div>

                <div className="profile-info">
                    <div className="username">@{user.username}</div>
                    <div className="bio">{user.bio}</div>
                </div>
                </div>
            </div>
            
            <div className="profile-tabs">
                <div className="tab active">
                    <span>POSTS</span>
                </div>
                <div className="tab">
                    <span>TAGGED</span>
                </div>
            </div>

            {userPosts.length === 0 
            ?<div className="empty-profile">
                <div className="empty-content">
                    <div className="camera-icon">
                        <svg aria-label="Camera" fill="#262626" height="62" viewBox="0 0 48 48" width="62">
                            <path d="M24 32.2c4.3 0 7.8-3.5 7.8-7.8s-3.5-7.8-7.8-7.8-7.8 3.5-7.8 7.8 3.5 7.8 7.8 7.8zm0-12.9c2.8 0 5.1 2.3 5.1 5.1s-2.3 5.1-5.1 5.1-5.1-2.3-5.1-5.1 2.3-5.1 5.1-5.1z"></path>
                            <path d="M40.3 12.2h-6.6c-1.1 0-2.1-.6-2.6-1.6l-2.3-4.5c-.7-1.3-2-2.1-3.5-2.1h-7.6c-1.4 0-2.8.8-3.5 2.1l-2.3 4.5c-.5 1-1.5 1.6-2.6 1.6H7.7c-3.8 0-6.7 3.1-6.7 6.7v18.9c0 3.7 3.1 6.7 6.7 6.7h32.6c3.7 0 6.7-3.1 6.7-6.7V18.9c-.1-3.6-3.1-6.7-6.8-6.7zm2.2 25.6c0 1.2-1 2.2-2.2 2.2H7.7c-1.2 0-2.2-1-2.2-2.2V18.9c0-1.2 1-2.2 2.2-2.2h6.6c1.1 0 2.1-.6 2.6-1.6l2.3-4.5c.2-.4.6-.7 1-.7h7.6c.4 0 .8.3 1 .7l2.3 4.5c.5 1 1.5 1.6 2.6 1.6h6.6c1.2 0 2.2 1 2.2 2.2v18.9z"></path>
                        </svg>
                    </div>
                    <div className="empty-title">No Posts Yet</div>
                </div>
            </div>
            :userPosts.map((post) => {
                return <UserPosts 
                key={post._id}
                postId={post._id}
                id={post.user_id}
                description={post.description} 
                image={post.media_url} 
                timePost={new Date(post.created_at.$date).toLocaleString()} 
                likes={post.likes || []}
                />
            })

            }
        </div>
    );
}