import React, { useEffect, useState } from 'react';
import './Profile.css'; 
import { toast } from 'react-toastify';
import { Link } from 'react-router-dom';
import Post from '../timeline/Post';
import { useDispatch, useSelector } from 'react-redux';
import { addPost, removePost, setPosts } from '../redux/export';

const Profile = () => {

  const dispatch = useDispatch();
  const posts = useSelector((state) => state.post.posts);

  const [profileData, setProfileData] = useState(null)
  const [description, setDescription] = useState('')
  const [media, setMedia] = useState(null)
  const [showAddPost, setShowAddPost] = useState(false)
  const [previewUrl, setPreviewUrl] = useState(null);
  const [loading, setLoading] = useState(true);

  const token = JSON.parse(localStorage.getItem('token'));

  const fetchProfie = async () => {
    try {
      const response = await fetch("http://127.0.0.1:5000/api/profile/me", {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      });
      const data = await response.json();

      if (data.success){
        setProfileData(data.data);
      }else{
        toast.error(data.message)
      }
    } catch (err) {
      console.log(err)
    } finally{
      setLoading(false);
    }
  }

  const hundleAddPost = async () => {

    const formData = new FormData();
    formData.append('description', description)
    formData.append('media', media)

    try {
      const response = await fetch('http://127.0.0.1:5000/api/posts/create', {
        method: "POST",
        headers: {
          'Authorization': `Bearer ${token}`,
        },
        body: formData,
      })

      const data = await response.json();
      if (data.success){
        toast.success(data.msg)
        dispatch(addPost(data.data))
        setDescription('')
        setMedia(null)
        setShowAddPost(false)
        setPreviewUrl(null)
        fetchProfie()
        await fetchMyPosts()
      }else{
        toast.error('Post creation failed')
      }
    } catch (err) {
      console.log(err)
    }
  }

   const fetchMyPosts = async () => {
    try {
      const response = await fetch('http://127.0.0.1:5000/api/posts/my-posts', {
        method: "GET",
        headers: { Authorization: `Bearer ${token}` },
      });
      const data = await response.json();

      if (data.success){
        dispatch(setPosts(data.data))
      }else{
        toast.error("Failed to fetch posts")
      }
    } catch (err) {
      console.log(err)
    }
  }

   useEffect(() => {
    fetchProfie()
  },[])

    if (loading) {
    return (
      <div className="loading-spinner-wrapper">
        <div className="spinner"></div>
      </div>
    );
  }

  const myPosts = posts && profileData?._id
  ? posts.filter(post => post && post.user_id === profileData._id)
  : [];

  return (
    <div className="profile-container">
      <div className='profile'>   
        <img
          src={
            profileData.avatar
              ? `http://localhost:5000${profileData.avatar}`
              : "https://i.pinimg.com/736x/15/0f/a8/150fa8800b0a0d5633abc1d1c4db3d87.jpg"
          }
          alt="profile"
          width="150"
        />
        <div>
          <div className="profile-header">
            <div className="profile-username">{profileData.username}</div>
            <div className="profile-actions">
              <Link to={'/edit'} className="edit-profile">Edit profile</Link>
              <button className="view-archive">View archive</button>
            </div>
          </div>

          <div className="profile-stats">
            <div className="stat">
              <span className="stat-number">{myPosts.length}</span>
              <span className="stat-label">posts</span>
            </div>
            <div className="stat">
              <span className="stat-number">{profileData.followers}</span>
              <span className="stat-label" style={{cursor: "pointer"}}>followers</span>
            </div>
            <div className="stat">
              <span className="stat-number" style={{cursor: "pointer"}}>{profileData.following.length}</span>
              <span className="stat-label">following</span>
            </div>
          </div>

          <div className="profile-info">
            <div className="username">@{profileData.username}</div>
            <div className="bio">{profileData.bio}</div>
          </div>
        </div>
      </div>
      
      <div className="profile-tabs">
        <div className="tab active">
          <span>POSTS</span>
        </div>
        <div className="tab">
          <span>SAVED</span>
        </div>
        <div className="tab">
          <span>TAGGED</span>
        </div>
      </div>

      {
        myPosts.length === 0 
        ? <div className="empty-profile">
            <div className="empty-content">
              <div className="camera-icon">
                <svg aria-label="Camera" fill="#262626" height="62" viewBox="0 0 48 48" width="62">
                  <path d="M24 32.2c4.3 0 7.8-3.5 7.8-7.8s-3.5-7.8-7.8-7.8-7.8 3.5-7.8 7.8 3.5 7.8 7.8 7.8zm0-12.9c2.8 0 5.1 2.3 5.1 5.1s-2.3 5.1-5.1 5.1-5.1-2.3-5.1-5.1 2.3-5.1 5.1-5.1z"></path>
                  <path d="M40.3 12.2h-6.6c-1.1 0-2.1-.6-2.6-1.6l-2.3-4.5c-.7-1.3-2-2.1-3.5-2.1h-7.6c-1.4 0-2.8.8-3.5 2.1l-2.3 4.5c-.5 1-1.5 1.6-2.6 1.6H7.7c-3.8 0-6.7 3.1-6.7 6.7v18.9c0 3.7 3.1 6.7 6.7 6.7h32.6c3.7 0 6.7-3.1 6.7-6.7V18.9c-.1-3.6-3.1-6.7-6.8-6.7zm2.2 25.6c0 1.2-1 2.2-2.2 2.2H7.7c-1.2 0-2.2-1-2.2-2.2V18.9c0-1.2 1-2.2 2.2-2.2h6.6c1.1 0 2.1-.6 2.6-1.6l2.3-4.5c.2-.4.6-.7 1-.7h7.6c.4 0 .8.3 1 .7l2.3 4.5c.5 1 1.5 1.6 2.6 1.6h6.6c1.2 0 2.2 1 2.2 2.2v18.9z"></path>
                </svg>
              </div>
              <div className="empty-title">Share Photos</div>
              <div className="empty-text">
                When you share photos, they will appear on your profile.
              </div>
              <button className="share-photo-button" onClick={() => setShowAddPost(true)}>Share your first photo</button>
            </div>
          </div>
        : myPosts.map((post) => {
          return (
            <Post 
              key={post._id} 
              id={post._id}
              userId={post.user_id} 
              description={post.description} 
              image={post.media_url} 
              timePost={new Date(post.created_at.$date).toLocaleString()} 
              likes={post.likes?.length || 0} 
              onDelete={() => dispatch(removePost(post._id))}
           />
          )
        }) 
      }

      {showAddPost && (
        <>
          <div className="add-post-overlay" onClick={() => setShowAddPost(false)} />
          <div className='add-post-form'>
            <h3>Create new post</h3>
            <p onClick={() => setShowAddPost(false)}>X</p>
            <input
              type='file'
              accept='image/*'
              onChange={(e) => {
                const file = e.target.files[0];
                setMedia(file);
                if (file) {
                  setPreviewUrl(URL.createObjectURL(file)); 
                }
              }}
              required
            />
            {previewUrl && (
              <div className="preview-image">
                <img src={previewUrl} alt="Preview" width="100%" style={{ maxHeight: '300px', objectFit: 'cover' }} />
              </div>
            )}
            <h3>Description</h3>
            <input 
              type="text"
              placeholder="Write a caption..."
              value={description}
              onChange={(e) => setDescription(e.target.value)}
            />
            <button onClick={hundleAddPost}>Post</button>
          </div>
        </>
      )}

    </div>
  );
};

export default Profile;