import { useEffect, useState } from "react";
import './Sidenav.css';
import insta from '../images/instaWord1.png';
import HomeFilledIcon from '@mui/icons-material/HomeFilled';
import SearchIcon from '@mui/icons-material/Search';
import ExploreIcon from '@mui/icons-material/Explore';
import AddBoxIcon from '@mui/icons-material/AddBox';
import CloseIcon from '@mui/icons-material/Close';
import LogoutIcon from '@mui/icons-material/Logout';
import { data, Link, useNavigate } from "react-router-dom";
import { useDispatch } from "react-redux";
import { addPost, logout, setPosts } from "../redux/export";
import { toast } from "react-toastify";


export default function Sidenav(){

    const [avatar, setAvatar] = useState("")
    const dispatch = useDispatch();
    const navigate = useNavigate();

    const [description, setDescription] = useState('')
    const [media, setMedia] = useState(null)
    const [showAddPost, setShowAddPost] = useState(false);
    const [previewUrl, setPreviewUrl] = useState(null);
    const [showSearch, setShowSearch] = useState(false);
    const [searchResults, setSearchResults] = useState([]);
    const [searchTerm, setSearchTerm] = useState('');

    const token = JSON.parse(localStorage.getItem('token'));

    const fetchPosts = async () => {
        try {
            fetch("http://127.0.0.1:5000/api/posts/all")
            .then(res => res.json())
            .then(data => dispatch(setPosts(data.data)))
        } catch (err) {
            console.log(err)
        }
    }
    
    const fetchProfile = async () => {
        try {
            const response = await fetch("http://127.0.0.1:5000/api/profile/me", {
                headers: {
                'Authorization': `Bearer ${token}`,
                'Content-Type': 'application/json'
                }
            });

            const data = await response.json();

            if (data.success){
                setAvatar(data.data.avatar)
            }else{
                toast.error(data.msg)
            }
        } catch (err) {
            console.log(err)
        }
    }

    const hundleAddPost = async () => {
    
        const formData = new FormData();
        formData.append('description', description)
        formData.append('media', media)

        try {
          
          const response = await fetch('http://127.0.0.1:5000/api/posts/create', {
            method: "POST",
            headers: {
              'Authorization': `Bearer ${token}`,
            },
            body: formData,
          })
    
          const data = await response.json();
          if (data.success){
            dispatch(addPost(data.data))
            toast.success(data.msg)
            setDescription('')
            setMedia(null)
            setShowAddPost(false)
            fetchPosts()
          }else{
            toast.error('Post creation failed')
          }
        } catch (err) {
          console.log(err)
        }
    }

    const fetchSearchResults = async (query) => {
        try {
            fetch(`http://127.0.0.1:5000/api/auth/search?name=${query}`)
            .then(res => res.json())
            .then(data => setSearchResults(data.results))
        } catch (err) {
            console.log(err)
        }
    }

    useEffect(() => {
        fetchProfile();
        fetchPosts();

        const delayDebounce = setTimeout(() => {
            if (searchTerm.trim() !== "") {
                fetchSearchResults(searchTerm.trim());
            } else {
                setSearchResults([]);
            }
        }, 300); // 300ms debounce

        return () => clearTimeout(delayDebounce);
    },[searchTerm])

    const handleLogout = () => {
        dispatch(logout());
        navigate("/login");
    }

    return(
        <div className="sidenav">
            <img src={insta} alt="" />
            <div className="sidenav-buttons">
                <Link className="sidenav-button" to={'/'} >
                    <HomeFilledIcon/>
                    <span>Home</span>
                </Link>
                <div className="sidenav-button" onClick={() => setShowSearch(true)}>
                    <SearchIcon/>
                    <span>Search</span>
                </div>
                <div className="sidenav-button">
                    <ExploreIcon/>
                    <span>Explore</span>
                </div>
                <div className="sidenav-button">
                    <AddBoxIcon/>
                    <span onClick={() => setShowAddPost(true)}>Creat</span>
                </div>
                <Link className="sidenav-btn" to={'/profile'}>
                    <img src={avatar ? `http://127.0.0.1:5000${avatar}` : "https://i.pinimg.com/736x/15/0f/a8/150fa8800b0a0d5633abc1d1c4db3d87.jpg" } 
                    alt="" />
                    <span>Profile</span>
                </Link>
            </div>
            <button className="logout" onClick={handleLogout}>
                <LogoutIcon/>
                <span>Log out</span>
            </button>

            {showAddPost && (
                <>
                <div className="add-post-overlay" onClick={() => setShowAddPost(false)} />
                <div className='add-post-form'>
                    <h3>Create new post</h3>
                    <p onClick={() => setShowAddPost(false)}>X</p>
                    <input
                    type='file'
                    accept='image/*'
                    onChange={(e) => {
                        const file = e.target.files[0];
                        setMedia(file);
                        if (file) {
                        setPreviewUrl(URL.createObjectURL(file)); 
                        }
                    }}
                    required
                    />
                    {previewUrl && (
                    <div className="preview-image">
                        <img src={previewUrl} alt="Preview"/>
                    </div>
                    )}
                    <h3>Description</h3>
                    <input 
                    type="text"
                    placeholder="Write a caption..."
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    />
                    <button onClick={hundleAddPost}>Post</button>
                </div>
                </>
            )}

            {showSearch && (
                <>
                <div className="search-overlay" onClick={() => setShowSearch(false)} />
                <div className="search-panel">
                    <div className="search-header">
                        <h3>Search</h3>
                        <CloseIcon onClick={() => setShowSearch(false)} style={{ cursor: 'pointer' }}/>
                    </div>
                    <input 
                        type="text"
                        placeholder="Search users..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        className="search-input"
                    />
                    <div className="search-results">
                        {searchResults.length > 0 ? (
                            searchResults.map(user => (
                                <Link 
                                    to={`/user-profile/${user._id}`} 
                                    className="search-user" 
                                    key={user._id}
                                    onClick={() => setShowSearch(false)}
                                >
                                    <img src={user.avatar ? `http://localhost:5000/${user.avatar}` : "https://i.pinimg.com/736x/15/0f/a8/150fa8800b0a0d5633abc1d1c4db3d87.jpg"} alt="" />
                                    <span>{user.username}</span>
                                </Link>
                            ))
                        ) : (
                            searchTerm && <p>No users found</p>
                        )}
                    </div>
                </div>
                </>
            )}
        </div>
    );
}